Not to be graded necessairily, but an alternate solution with a few errors. PA not
designed with this strategy in mind but figured it may be worth including