Unfortunetly does not pass all test cases, couldn't quite figure out the last bug
or two, but the code went through many iterations (additional one included) and at
some point I've got to prioritize keeping up with the class over debugging an already
late code, and I'm fairly confident I've demonstrated an understanding of the
material despite a bug or two